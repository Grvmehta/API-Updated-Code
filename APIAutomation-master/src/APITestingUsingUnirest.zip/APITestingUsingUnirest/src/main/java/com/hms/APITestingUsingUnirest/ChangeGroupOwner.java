package com.hms.APITestingUsingUnirest;

import org.json.JSONObject;

import com.hms.APITestingUsingUnirest.Generic.ApiUtils;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class ChangeGroupOwner {
	
static String responseJSONString;
	
	String keytype;
	String accesskey;
	String serverurl;
	String hotelid1;
	String bookingid;
	String editbookingid;	
	String Ownerid;
	
	
	public void fn_changegroupowner(String s1){
		
		keytype = s1;
		
		System.out.println("Welcome to Change group Owner API");
		
		if(keytype == "wsauth")
		{
			Wsauth objwsauth = new Wsauth();
			objwsauth.Wsauthcall();
			String keyw = objwsauth.extractingWsauthKey();
			accesskey = keyw;
		}
		
		else if(keytype == "login")
		{
			Login objlogin = new Login();
			objlogin.Logincall();
			String keyl = objlogin.extractingLoginKey();
			accesskey = keyl;
		}
		try
		{
			System.out.println("Hello Change group Owner API");
			serverurl = CommonConfig.serverurl;
			hotelid1 = CommonConfig.hotelid1;	
	
			
			System.out.println("Welcome EditBooking API");
			Editbooking editbookingobj = new Editbooking();
			editbookingobj.Editbookingcall("login", "G", "RESERVE");
		    editbookingid = editbookingobj.extracttinggroupid();
		    Ownerid = editbookingobj.extracttingowneridfromgroup();	   
			String fname = ApiUtils.GA().generateRandomString();
			
			
			 HttpResponse<JsonNode> responseaddbookingtogroup = Unirest.post(""+serverurl+"/ws/web/changegroupowner")
	                .header("content-type", "application/json")
	                .header("x-ig-sg", "D_gg%fkl85_j")
	                .header("cache-control", "no-cache")
	                .header("postman-token", "586c8072-4a88-dff1-cb04-294c764db5d7")
	                .body("{"
	                		+ "\"hotelogix\": {"
	                		+ "\"version\": \"1.0\","
	                		+ "\"datetime\": \"2012-01-16T10:10:15\","
	                		+ "\"request\": {"
	                		+ "\"method\": \"changegroupowner\","
	                		+ "\"key\": \""+accesskey+"\","
	                		+ "\"languagecode\": \"en\","
	                		+ "\"data\": {"
	                		+ "\"id\": \""+editbookingid+"\","
	                		+ "\"ownerType\": \"guest\","
	                		+ "\"owner\": {"
	                		+ "\"id\": \""+Ownerid+"\","
	                		+ "\"contacts\": {"
	                		+ "\"personal\": {"
	                		+ "\"salutation\": \"Dr\","
	                		+ "\"fName\": \""+fname+"\","
	                		+ "\"lName\": \"NewLastName\","
	                		+ "\"gender\": \"F\","
	                		+ "\"designation\": \"Manager\","
	                		+ "\"phoneNo\": \"94372934\","
	                		+ "\"faxNo\": \"0202\","
	                 		+ "\"email\": \""+fname+"+new.com\","
	                		+ "\"mobileNo\": \"08340348034\""             	
	                		+ "},"
	                		+ "\"addresses\": ["
	                		+ "{"
	                		+ "\"type\": \"home\"," 
	                		+ "\"address\": \"patn1331a44\"," 
	                		+ "\"country\": \"IN\","
	                		+ "\"state\": \"AP\","
	                		+ "\"city\": \"mycity134431\","
	                		+ "\"zip\": \"33333133441\","
	                		+ "\"fax\": \"55667777711\""
	                		+ "},"
	                		+ "{"
	                		+ "\"type\": \"billing\"," 
	                		+ "\"address\": \"patn1331a44\"," 
	                		+ "\"country\": \"IN\"," 
	                		+ "\"state\": \"CH\"" 
	                		+ "}"
	                		+ "],"
	                		+ "\"otherDetails\": {"
	                		+ "\"spouseSalutation\": \"Dr.\"," 
	                		+ "\"spouseLName\": \"Ranii918\""          	          	
	                		+ "}}}}}}}")
	                     .asJson();
			    	JsonNode body = responseaddbookingtogroup.getBody();  		    	
			    	responseJSONString = body.toString();
			    	System.out.println("Add Bookings to Group:"+responseJSONString);
				}
		    	catch(UnirestException e)
		    	{
		    	e.printStackTrace();
		    
		}	
	}			
			
	 public String extractingmessagechangegroupowner()
			{
			try
			{
				String localresponseJSONString = responseJSONString;
				JSONObject jsonResult = new JSONObject(localresponseJSONString);
				String changegroupowner;
				changegroupowner = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONObject("status").getString("message");
				System.out.println("at last getbookings success:"+changegroupowner);
				return changegroupowner;
				}
			
			finally{
		Commiteditbooking commiteditbookingobj = new Commiteditbooking();
		commiteditbookingobj.CommiteditBookingCallForExistingBookingid("login","G", editbookingid);
	}
		    

		
			
			}
}

	


