package com.hms.APITestingUsingUnirest;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CommonConfig 

{

	//ADMIN AND WEB
 public static String serverurl = "http://hotelogix.net";
	public static String key = "7FF9EEC2BC75400D6F13688543F9683A4CE88D6A";

	public static String hotelid1 ="6209";
	public static String hotelid2 ="10554";
	public static String emailid = "muk.esh.kumar@hotelogix.com";
	public static String password = "111111";

	public static String roomtypecode1hotelid1 = "CLS";
	public static String roomtypecode2hotelid1 = "CLD";
	public static String roomtypecode1hotelid2 = "st";
	public static String roomtypecode2hotelid2 = "dl";

	public static String ratecode1hotelid1 = "cpr";
	public static String ratecode2hotelid1 = "6209199360ntpon";
	public static String ratecode1hotelid2 = "";
	public static String ratecode2hotelid2 = "";

	public static String dailyratecode1hotelid1 = "BB";
	public static String dailyratecode2hotelid2 = "BB";

	public static String nightauditdate = "2015-07-29";
	//public static String nightauditdate1 = "2015-08-20";
	public static String nightauditdate1 = "2015-08-27";
	public static String nightauditdate2 = "2015-08-24";
	public static String nightauditdate3 = "2015-08-28";
	public static String nightauditdate4 = "2015-08-29";
	//public static String nightauditdate5 = "2015-08-30";
	
//FRONTDESK 
/*
public static String serverurl = "http://hotelogix.net";	
public static String key = "7FF9EEC2BC75400D6F13688543F9683A4CE88D6A";

public static String hotelid1 ="10554";
public static String hotelid2 ="";
public static String emailid = "nimrit21@gmail.com";
public static String password = "111111";

public static String roomtypecode1hotelid1 = "st";
public static String roomtypecode2hotelid1 = "dl";
public static String roomtypecode1hotelid2 = "";
public static String roomtypecode2hotelid2 = "";

public static String ratecode1hotelid1 = "MAP";
public static String ratecode2hotelid1 = "HnPk";
public static String ratecode1hotelid2 = "";
public static String ratecode2hotelid2 = "";

public static String dailyratecode1hotelid1 = "BB";
public static String dailyratecode2hotelid2 = "BB";

//public static String nightauditdate = "2015-03-09";
//public static String nightauditdate1 = "2015-03-10";
//public static String nightauditdate2 = "2015-03-11";

public static String nightauditdate = "2015-03-09";
public static String nightauditdate1 = "2015-03-09";
public static String nightauditdate2 = "2015-03-08";
*/
/*
public static String serverurl = "https://staygrid.com";
public static String key = "5E78B100CCC0485D67CC81C36AFE7C10CD79D08A";

public static String hotelid1 ="33946";
public static String hotelid2 ="10554";
public static String emailid = "jitu132@gmail.com";
public static String password = "111111";

public static String roomtypecode1hotelid1 = "DL";
public static String roomtypecode2hotelid1 = "SDL";
public static String roomtypecode1hotelid2 = "st";
public static String roomtypecode2hotelid2 = "dl";

public static String ratecode1hotelid1 = "TESTAUTO1";
public static String ratecode2hotelid1 = "TESTAUTO2";
public static String ratecode1hotelid2 = "";
public static String ratecode2hotelid2 = "";

public static String dailyratecode1hotelid1 = "339467226321DRP";
public static String dailyratecode2hotelid2 = "BB";

public static String nightauditdate = "2015-07-26";
public static String nightauditdate1 = "2015-10-01";
public static String nightauditdate2 = "2015-09-30";
public static String nightauditdate3 = "2015-10-02";
public static String nightauditdate4 = "2015-08-03";
*/
}



