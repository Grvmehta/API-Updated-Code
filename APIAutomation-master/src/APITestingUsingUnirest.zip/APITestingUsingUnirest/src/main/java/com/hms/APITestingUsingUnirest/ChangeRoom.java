package com.hms.APITestingUsingUnirest;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class ChangeRoom {
	static String responseJSONString;
	String keytype;
	String accesskey;
	String serverurl;
	String hotelid1;
	String bookingid;
	String roomid;


	public void fn_changeRoom(String s1)
	{
		
			keytype = s1;
			
			if(keytype == "wsauth")
			{
				Wsauth objwsauth = new Wsauth();
				objwsauth.Wsauthcall();
				String keyw = objwsauth.extractingWsauthKey();
				accesskey = keyw;
			}
			
			else if(keytype == "login")
			{
				Login objlogin = new Login();
				objlogin.Logincall();
				String keyl = objlogin.extractingLoginKey();
				accesskey = keyl;
			}
			try
			{
				System.out.println("hello try createagent");
				serverurl = CommonConfig.serverurl;
 			    hotelid1 = CommonConfig.hotelid1;	
										
				Assignroom assignroomobj = new Assignroom();
				assignroomobj.assignroomcall("login");
				String  editbookingid = assignroomobj.editbookigid;			
		        
				Editbooking editbookingobj = new Editbooking();
				editbookingobj.fn_editbookingcallforexistingbookingid("login", editbookingid, "S");
				
				
				Getroomstoassign Getroomstoassignobj=new Getroomstoassign();
				Getroomstoassignobj.getroomstoassigncall("login", assignroomobj.editbookigid);
				roomid = Getroomstoassignobj.extractingroomid();
				
			     
				
				HttpResponse<JsonNode> responseassignrom = Unirest.post(""+serverurl+"/ws/web/changeroom")
						 .header("content-type", "application/json")
						 .header("x-ig-sg", "D_gg%fkl85_j")
						 .header("cache-control", "no-cache")
						 .header("postman-token", "c52633bd-8abb-e05d-ec86-0641bf085b8f")
						 .body("{"
						               	+ "\"hotelogix\": {"
						               	+ "\"version\": \"1.0\","
						               	+ "\"datetime\": \"2012-01-16T10:10:15\","
						               	+ "\"request\": {"
						               	+ "\"method\": \"changeroom\","
						               	+ "\"key\": \""+accesskey+"\","
						               	+ "\"data\": {"
						               	+ "\"bookings\": ["
						               	+ "{"
						               	+ "\"id\": \""+editbookingid+"\","
						               	+ "\"roomId\":\""+roomid+"\""
						               	+ "}]}}}}")
						                    .asJson();
						JsonNode body = responseassignrom.getBody();
						responseJSONString = body.toString();
						System.out.println("Response of AssignRoom");
						System.out.println("assignroom:"+responseJSONString);
			}
	    	catch(UnirestException e)
	    	{
	    	e.printStackTrace();
	    	}

	}
	
}
