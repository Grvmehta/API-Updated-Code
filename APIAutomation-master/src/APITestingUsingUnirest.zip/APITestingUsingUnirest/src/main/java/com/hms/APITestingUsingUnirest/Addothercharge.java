package com.hms.APITestingUsingUnirest;

import org.json.JSONObject;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class Addothercharge {

String posid;
static String bookingid;
String discountamt;
 String responseJSONString;
String serverurl;
String hotelid1;
String keytype; 
String accesskey;
   String message;

public void Addotherchargecall(String s1){
keytype = s1;

if(keytype == "wsauth")

{
System.out.println("hello to Addothercharge block:");

String keyw = Wsauth.wsauthkeyfinalstring;
accesskey = keyw;
System.out.println("wsauthkey in Addothercharge:"+keyw);
}

else if(keytype == "login")
{	
String keyl = Login.finalloginaccesskey;
System.out.println("login key in Addothercharge:"+keyl);
accesskey = keyl;
}
try{
   serverurl = CommonConfig.serverurl;
hotelid1 = CommonConfig.hotelid1;
System.out.println("hello try"+accesskey);
/*Getbookings getbookingsobj = new Getbookings();
getbookingsobj.Getbookingscall("login");
bookingid= getbookingsobj.extractingmainid();
System.out.println("Booking id from getbookings:"+bookingid);*/

Getbookings getbookingsobj = new Getbookings();
getbookingsobj.Getbookingscall("login", "CHECKIN");
bookingid = getbookingsobj.extractingmainid();
System.out.println("Booking Id for getbookings:" +bookingid);
Getpos getposobj=new Getpos();
getposobj.Getposcall(keytype);
posid=getposobj.extractingposid();
Getposproduct getposproductobj=new Getposproduct();
getposproductobj.Getposproductcall(keytype);
String productid=getposproductobj.extractingposproductid();

HttpResponse<JsonNode> responseaddothercharge = Unirest.post(""+serverurl+"/ws/web/addothercharge")
 .header("content-type", "application/json")
 .header("x-ig-sg", "D_gg%fkl85_j")
 .header("cache-control", "no-cache")
 .header("postman-token", "68c17692-2456-7fd3-6057-fe652a0d60eb")
 .body("{ \"hotelogix\": {"
               	+ "\"version\": \"1.0\","
               	+ "\"datetime\": \"2015-09-16T11:01:29\","
               	+ " \"request\": {"
               	+ " \"method\": \"addothercharge\","
               	+ "\"key\": \""+accesskey+"\","
               	+ "\"data\": {"
               	+ "\"chargeType\": \"room\","
               	+ "\"bookingId\": \""+bookingid+"\","
               	+ "\"posId\": \""+posid+"\","
               	+ "\"productId\": \""+productid+"\","
               	+ "\"quantity\": \"1\","
               	+ "\"discount\": \""+discountamt+"\","
               	+ "\"discountType\": \"FV\""
               	+ "}}}}")
 .asJson();
JsonNode body = responseaddothercharge.getBody();
responseJSONString = body.toString();
System.out.println(responseJSONString);
}catch(UnirestException e)
{
e.printStackTrace();
}

}



public String extractingmessageAddothercharge() {

System.out.println("welcome to extractingmessageAddothercharge");
String localresponseJSONString = responseJSONString;
JSONObject jsonResult = new JSONObject(localresponseJSONString);
message = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONObject("status").getString("message");
System.out.println("status msg of addothercharge:"+message);
return message;
}


}
