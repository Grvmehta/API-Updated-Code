package com.hms.APITestingUsingUnirest;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.*;

import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.hms.APITestingUsingUnirest.CommonConfig;

public class Editbooking
{
static String responseJSONString;
	
	String serverurl;
	String hotelid1;
	String keytype;
	String bookingtype;
	String accesskey;
	String restype;
	String searchkey;
	static String getbookingstempid;
	static String groupid;
	String BookingID;
	String guestStayId;
	String rateidforchange;
	String guestdetailsid;
	String RoomID;

	String Noofroom;

	String isGroupBookingValue;
	
	public void Editbookingcall(String s1)
	{
		System.out.println("welcome to editbookingcall with one parameter");
		keytype = s1;
		System.out.println("keytype:"+s1);
		
		if(keytype == "wsauth")
		{
			/*Wsauth objwsauth = new Wsauth();
			objwsauth.Wsauthcall();
			String keyw = objwsauth.extractingWsauthKey();
			accesskey = keyw;
			System.out.println("hello if"+ accesskey);*/
			
			String keyw = Wsauth.wsauthkeyfinalstring;
			accesskey = keyw;
			System.out.println("wsauthkey in addtocart:"+keyw);
		}
		
		else if(keytype == "login")
		{
			/*Login objlogin = new Login();
			objlogin.Logincall();
			String keyl = objlogin.extractingLoginKey();
			System.out.println("login key in gethousestatus:"+keyl);
			accesskey = keyl;*/
			
			String keyl = Login.finalloginaccesskey;
			System.out.println("login key in editbooking:"+keyl);
			accesskey = keyl;
		}
		
		try
		{
			serverurl = CommonConfig.serverurl;
			
			Getbookings getbookingsobj = new Getbookings();
			getbookingsobj.Getbookingscall("login");
			String mainid = getbookingsobj.extractingmainid();
			System.out.println("getbookings mainid in editbooking:"+mainid);
			
			HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
					  .header("content-type", "application/json")
					  .header("x-ig-sg", "D_gg%fkl85_j")
					  .header("cache-control", "no-cache")
					  .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
					  .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \"S\",\r\n         \"id\": \""+mainid+"\"\r\n      }\r\n    }\r\n  }\r\n }")
					  .asJson();
			JsonNode body = responseeditbooking.getBody();
			responseJSONString = body.toString();	
		}
		catch(UnirestException e)
		{
			e.printStackTrace();
		}
	}// End of Editbookingcall(s1) method
	
	
	public void Editbookingcall(String s1, String s2, String s3)
	{
		System.out.println("welcome to editbookingcall with the parameters");
		keytype = s1;
		bookingtype = s2;
		restype = s3;
		
		
		System.out.println("keytype::"+s1);
		System.out.println("bookingtype::"+s2);
		System.out.println("restype::"+s3);
		
		if(keytype == "wsauth")
		{
			Wsauth objwsauth = new Wsauth();
			objwsauth.Wsauthcall();
			String keyw = objwsauth.extractingWsauthKey();
			accesskey = keyw;
			System.out.println("hello if"+ accesskey);
		}
		
		else if(keytype == "login")
		{
			/*Login objlogin = new Login();
			objlogin.Logincall();
			String keyl = objlogin.extractingLoginKey();
			System.out.println("login key in gethousestatus:"+keyl);
			accesskey = keyl;*/
			
			String keyl = Login.finalloginaccesskey;
			System.out.println("login key in editbooking:"+keyl);
			accesskey = keyl;
		}
		
		try
		{
			serverurl = CommonConfig.serverurl;
			
			Getbookings getbookingsobj = new Getbookings();
			getbookingsobj.Getbookingscall(keytype,restype);
			//String mainid = getbookingsobj.extractinggroupmainid();
			//getbookingsobj.extractingmainid();
			getbookingsobj.extractinggroupmainid();
			//getbookingsobj.extractinggroupcode();
			String mainid = Getbookings.getGroupTempID;
			//String mainid = Getbookings.getGroupCode;
			
			System.out.println("getbookings group mainid in editbooking::"+mainid);
			
			HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
					  .header("content-type", "application/json")
					  .header("x-ig-sg", "D_gg%fkl85_j")
					  .header("cache-control", "no-cache")
					  .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
					  .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \""+bookingtype+"\",\r\n         \"id\": \""+mainid+"\"\r\n      }\r\n    }\r\n  }\r\n }")
					  .asJson();
			JsonNode body = responseeditbooking.getBody();
			responseJSONString = body.toString();	
			System.out.println(responseJSONString);
		}
		catch(UnirestException e)
		{
			e.printStackTrace();
		}
	}
	// End of Editbookingcall(s1,s2,s3) method
	public void EditbookingcallforConfirmBookingidforFutureDate(String s1,String s2,String s3){
		keytype = s1;
		Noofroom=s2;
		isGroupBookingValue=s3;
		System.out.println("keytype:"+s1);

		if(keytype == "wsauth")
		{
		/*Wsauth objwsauth = new Wsauth();
		objwsauth.Wsauthcall();
		String keyw = objwsauth.extractingWsauthKey();
		accesskey = keyw;
		System.out.println("hello if"+ accesskey);*/

		String keyw = Wsauth.wsauthkeyfinalstring;
		accesskey = keyw;
		System.out.println("wsauthkey in addtocart:"+keyw);
		}

		else if(keytype == "login")
		{
		/*Login objlogin = new Login();
		objlogin.Logincall();
		String keyl = objlogin.extractingLoginKey();
		System.out.println("login key in gethousestatus:"+keyl);
		accesskey = keyl;*/

		String keyl = Login.finalloginaccesskey;
		System.out.println("login key in editbooking:"+keyl);
		accesskey = keyl;
		}

		try
		{
		serverurl = CommonConfig.serverurl;
		Confirmbooking Confirmbookingobj=new Confirmbooking();
		Confirmbookingobj.ConfirmbookingcallforFrontDeskforfutureDate(keytype,Noofroom,isGroupBookingValue);
		String mainid =Confirmbookingobj.extracingbookingid();
		System.out.println("confirmbookings mainid in editbooking:"+mainid);
		HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
		 .header("content-type", "application/json")
		 .header("x-ig-sg", "D_gg%fkl85_j")
		 .header("cache-control", "no-cache")
		 .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
		 .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \"S\",\r\n         \"id\": \""+mainid+"\"\r\n      }\r\n    }\r\n  }\r\n }")
		 .asJson();
		JsonNode body = responseeditbooking.getBody();
		responseJSONString = body.toString();
		System.out.println("Editbooking rspns from confirm booking:"+responseJSONString);
		}
		catch(UnirestException e)
		{
		e.printStackTrace();
		}
		}
	
	
	
	public void Editbookingcall(String s1, String s2)
	{
		System.out.println("welcome to editbookingcall with two parameters");
		keytype = s1;
		searchkey = s2;
		
		
		
		System.out.println("keytype::"+s1);
		System.out.println("searchkey::"+s2);
		
		
		if(keytype == "wsauth")
		{
			/*Wsauth objwsauth = new Wsauth();
			objwsauth.Wsauthcall();
			String keyw = objwsauth.extractingWsauthKey();
			accesskey = keyw;
			System.out.println("hello if"+ accesskey);*/
			
			String keyw = Wsauth.wsauthkeyfinalstring;
			accesskey = keyw;
			System.out.println("wsauthkey in editbooking:"+keyw);
		}
		
		else if(keytype == "login")
		{
			/*Login objlogin = new Login();
			objlogin.Logincall();
			String keyl = objlogin.extractingLoginKey();
			System.out.println("login key in gethousestatus:"+keyl);
			accesskey = keyl;*/
			
			String keyl = Login.finalloginaccesskey;
			System.out.println("login key in editbooking:"+keyl);
			accesskey = keyl;
		}
		
		try
		{
			serverurl = CommonConfig.serverurl;
			
			//NEW >>>Getbookings getbookingsobj = new Getbookings();
			//NEW >>> getbookingsobj.Getbookingscall(keytype,restype);
			//NEW >>>getbookingsobj.Getbookingscall("login","RESERVE");
			//NEW >>>String mainid = getbookingsobj.extractinggroupmainid();
			Getbookings getbookingsobj = new Getbookings();
		    getbookingsobj.Getbookingscall("login");
		    //String mainid1 =getbookingsobj.extractinggrouptempid();
		    String mainid2 = getbookingsobj.extractinggroupmainid();
		    System.out.println("This is" +mainid2);
		
			//getbookingsobj.extractingmainid();
			
			/*getbookingsobj.extractinggroupmainid();
			String mainid = Getbookings.getGroupTempID;
			System.out.println("getbookings group mainid in editbooking::"+mainid);*/
			
			//Getbookingsearch getbookingsearchobj = new Getbookingsearch();
			//getbookingsearchobj.Getbookingsearchcall(keytype, searchkey);
			//String mainid = getbookingsearchobj.extractingmainid();
			
			
			HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
					  .header("content-type", "application/json")
					  .header("x-ig-sg", "D_gg%fkl85_j")
					  .header("cache-control", "no-cache")
					  .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
					  .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \"G\",\r\n         \"id\": \""+mainid2+"\"\r\n      }\r\n    }\r\n  }\r\n }")
					  .asJson();
			JsonNode body = responseeditbooking.getBody();
			responseJSONString = body.toString();	
			System.out.println("editbooking:"+responseJSONString);
		}
		catch(UnirestException e)
		{
			e.printStackTrace();
		}
	}// End of Editbookingcall(s1,s2) method
	

    public void EditbookingcallforReserveGuest(String s1, String s2){
    System.out.println("welcome to editbookingcall with one parameter");
    keytype = s1;
    restype = s2;
    System.out.println("keytype:"+s1);

    if(keytype == "wsauth")
    {

    String keyw = Wsauth.wsauthkeyfinalstring;
    accesskey = keyw;
    System.out.println("wsauthkey in addtocart:"+keyw);
}

    else if(keytype == "login")
    {

    String keyl = Login.finalloginaccesskey;
    System.out.println("login key in editbooking:"+keyl);
    accesskey = keyl;
}

try
{
serverurl = CommonConfig.serverurl;

Getbookings getbookingsobj = new Getbookings();
getbookingsobj.Getbookingscallforreserveguest("login");
rateidforchange = getbookingsobj.extractingrateid();
String mainid = getbookingsobj.extractinggroupmainid();
System.out.println("getbookings mainid in editbooking:"+mainid);

HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
 .header("content-type", "application/json")
 .header("x-ig-sg", "D_gg%fkl85_j")
 .header("cache-control", "no-cache")
 .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
 .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \""+restype+"\",\r\n         \"id\": \""+mainid+"\"\r\n      }\r\n    }\r\n  }\r\n }")
 .asJson();
JsonNode body = responseeditbooking.getBody();
responseJSONString = body.toString();
System.out.println(responseJSONString);
}
catch(UnirestException e)
{
e.printStackTrace();
}
}
    public void EditbookingcallforConfirmBookingid(String s1){
    	System.out.println("welcome to editbookingcall with one parameter");
    	keytype = s1;
    	System.out.println("keytype:"+s1);

    	if(keytype == "wsauth")
    	{
    	/*Wsauth objwsauth = new Wsauth();
    	objwsauth.Wsauthcall();
    	String keyw = objwsauth.extractingWsauthKey();
    	accesskey = keyw;
    	System.out.println("hello if"+ accesskey);*/

    	String keyw = Wsauth.wsauthkeyfinalstring;
    	accesskey = keyw;
    	System.out.println("wsauthkey in addtocart:"+keyw);
    	}

    	else if(keytype == "login")
    	{
    	/*Login objlogin = new Login();
    	objlogin.Logincall();
    	String keyl = objlogin.extractingLoginKey();
    	System.out.println("login key in gethousestatus:"+keyl);
    	accesskey = keyl;*/

    	String keyl = Login.finalloginaccesskey;
    	System.out.println("login key in editbooking:"+keyl);
    	accesskey = keyl;
    	}

    	try
    	{
    	serverurl = CommonConfig.serverurl;
    	Confirmbooking Confirmbookingobj=new Confirmbooking();
    	Confirmbookingobj.ConfirmbookingcallforFrontDesk("login");
    	String mainid =Confirmbookingobj.extracingbookingid();
    	/*Getbookings getbookingsobj = new Getbookings();
    	getbookingsobj.Getbookingscall("login");
    	String mainid = getbookingsobj.extractingmainid();*/
    	System.out.println("confirmbookings mainid in editbooking:"+mainid);

    	HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
    	 .header("content-type", "application/json")
    	 .header("x-ig-sg", "D_gg%fkl85_j")
    	 .header("cache-control", "no-cache")
    	 .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
    	 .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \"S\",\r\n         \"id\": \""+mainid+"\"\r\n      }\r\n    }\r\n  }\r\n }")
    	 .asJson();
    	JsonNode body = responseeditbooking.getBody();
    	responseJSONString = body.toString();
    	System.out.println("Editbooking rspns from confirm booking:"+responseJSONString);
    	}
    	catch(UnirestException e)
    	{
    	e.printStackTrace();
    	}

    	}
    
    public void fn_editbookingcallforexistingbookingid(String s1, String s2, String s3){
    	
    	System.out.println("welcome to editbookingcall for EditBooking for Existing Booking id");
		keytype = s1;
		BookingID = s2;
		restype = s3;
		System.out.println("keytype:"+s1);
		
		if(keytype == "wsauth")
		{
	
			String keyw = Wsauth.wsauthkeyfinalstring;
			accesskey = keyw;
			System.out.println("wsauthkey in addtocart:"+keyw);
		}
		
		else if(keytype == "login")
		{	
			
			String keyl = Login.finalloginaccesskey;
			System.out.println("login key in editbooking:"+keyl);
			accesskey = keyl;
		}
		
		try
		{
			serverurl = CommonConfig.serverurl;
			System.out.println("getbookings mainid in editbooking:"+BookingID);
			
			HttpResponse<JsonNode> responseeditbooking = Unirest.post(""+serverurl+"/ws/web/editbooking")
					  .header("content-type", "application/json")
					  .header("x-ig-sg", "D_gg%fkl85_j")
					  .header("cache-control", "no-cache")
					  .header("postman-token", "04356b9d-f04a-9171-2772-e7bb2fb534cc")
					  .body("{\r\n  \"hotelogix\": {\r\n   \"version\": \"1.0\",\r\n    \"datetime\": \"2012-01-16T10:10:15\",\r\n    \"request\": {\r\n      \"method\": \"editbooking\",\r\n      \"key\": \""+accesskey+"\",\r\n      \"data\": {\r\n         \"type\": \""+restype+"\",\r\n         \"id\": \""+BookingID+"\"\r\n      }\r\n    }\r\n  }\r\n }")
					  .asJson();
			JsonNode body = responseeditbooking.getBody();
			System.out.println("new");
			responseJSONString = body.toString();	
		}
		catch(UnirestException e)
		{
			e.printStackTrace();
		}
    	
    }
	
	public String extractingmessageeditbooking()
	{
		System.out.println("welcome to extractingmessageeditbooking");
		String localresponseJSONString = responseJSONString;
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		String editbookingstring;
		editbookingstring = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONObject("status").getString("message");
		System.out.println("at last getbooking success:"+editbookingstring);
		
		return editbookingstring;
	}//End of extractingmessageeditbooking() method
	
	public String extractingtempid()
	{
		System.out.println("welcome to extractingtempid");
		String localresponseJSONString = responseJSONString;
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		
		JSONArray getbookingsArray = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONArray("bookings");
		JSONObject bookingstempid = getbookingsArray.getJSONObject(0);
		getbookingstempid = bookingstempid.getString("id");
		System.out.println(":getbookings mainid:"+getbookingstempid);
		
		return getbookingstempid;
	}//End of extractingtempid() method
	
	public String extracttinggroupid()
	{
		System.out.println("welcome to groupid2");
		String localresponseJSONString = responseJSONString;
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		JSONArray getbookingsArray = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONArray("bookings");
		JSONObject bookingstempid = getbookingsArray.getJSONObject(0);
		JSONObject grp = bookingstempid.getJSONObject("group");
		String groupid = grp.getString("id");
		System.out.println(":getbookings id:"+groupid);
		
		return groupid;
	}
	
	public String extracttingowneridfromgroup()
	{
		System.out.println("welcome to Extracting Owner id of group reservation");
		String localresponseJSONString = responseJSONString;
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		JSONArray getbookingsArray = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONArray("bookings");
		JSONObject bookingstempid = getbookingsArray.getJSONObject(0);
		JSONObject grp = bookingstempid.getJSONObject("group");
		JSONObject ownerobj = grp.getJSONObject("owner");
		String ownerid = ownerobj.getString("id");
		System.out.println(":Owner ID :"+ownerid);
		
		return ownerid;
	}
	
	
	public String extractingguestStayId(){
		System.out.println("welcome to extractingguestid");
		String localresponseJSONString = responseJSONString;
		System.out.println(localresponseJSONString);
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		JSONArray getbookingsArray = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONArray("bookings");
		System.out.println(getbookingsArray.length());
		JSONObject bkgObj=getbookingsArray.getJSONObject(0);
		BookingID=bkgObj.getString("id");
		System.out.println(BookingID);
		JSONArray gueststaysarr=bkgObj.getJSONArray("guestStays");
		System.out.println(gueststaysarr.length());
		JSONObject gueststay=gueststaysarr.getJSONObject(0);
		guestStayId= gueststay.getString("id");
		System.out.println(guestStayId);
		System.out.println("Guest Stays Id from editbooking:"+guestStayId);
        
			
		return guestStayId;
		}
	

	public String extractingguestStayIdofSecondGuest(){
		System.out.println("welcome to extractingguestid");
		String localresponseJSONString = responseJSONString;
		System.out.println(localresponseJSONString);
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		JSONArray getbookingsArray = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONArray("bookings");
		System.out.println(getbookingsArray.length());
		JSONObject bkgObj=getbookingsArray.getJSONObject(0);
		BookingID=bkgObj.getString("id");
		System.out.println(BookingID);
		JSONArray gueststaysarr=bkgObj.getJSONArray("guestStays");
		System.out.println(gueststaysarr.length());
		JSONObject gueststay=gueststaysarr.getJSONObject(1);
		guestStayId= gueststay.getString("id");
		System.out.println(guestStayId);
		System.out.println("Guest Stays Id from editbooking:"+guestStayId);
        
			
		return guestStayId;
		}
	
	public String extractingdetailsId(){
		
		System.out.println("welcome to extractingguestid");
		String localresponseJSONString = responseJSONString;
		System.out.println(localresponseJSONString);
		JSONObject jsonResult = new JSONObject(localresponseJSONString);
		JSONArray getbookingsArray = jsonResult.getJSONObject("hotelogix").getJSONObject("response").getJSONArray("bookings");
		System.out.println(getbookingsArray.length());
		JSONObject bkgObj=getbookingsArray.getJSONObject(0);
		BookingID=bkgObj.getString("id");
		System.out.println(BookingID);
		JSONArray gueststaysarr=bkgObj.getJSONArray("guestStays");		
		JSONObject gueststay=gueststaysarr.getJSONObject(0);
		JSONObject new1 = gueststay.getJSONObject("guestDetails");
		guestdetailsid = new1.getString("id");
		
		return guestdetailsid;
	}
	
 
}
